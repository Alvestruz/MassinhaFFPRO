MASSINHA FF PRO — projeto Android nativo (código-fonte beta 0.2)

Este ZIP contém um projeto para abrir no Android Studio e compilar um APK.
Não é um APK pronto e não foi compilado/testado em um Galaxy A50 nesta sessão.

Funções implementadas no código:
- Tela inicial escura azul/neon inspirada na organização vista no vídeo Zayon.
- Consulta de aplicativos com ícone de launcher para seleção.
- Botão de abrir Free Fire normal pelo pacote com.dts.freefireth.
- Leitura de memória RAM e nível de bateria.
- Solicitação de permissão Android para sobreposição.
- Bolinha flutuante que oferece atalho para abrir Free Fire; toque longo fecha.

Limitações:
- A lista de apps é apresentada como seletor; o salvamento da biblioteca ainda é básico.
- Não modifica arquivos, texturas, shaders, resolução ou configurações internas do Free Fire.
- Os controles gráficos são apenas protótipos de interface. Não prometem massinha nem aumento de FPS.
- A bolinha não controla o jogo; é um atalho flutuante.
- Requer Android Studio, SDK Android 34 e JDK 17 para compilar com AGP 8.2.2.
- Teste primeiro em aparelho secundário/em ambiente controlado. Não há garantia de compatibilidade sem compilação e teste físico.

Como compilar:
1. Extraia o ZIP.
2. Abra a pasta MassinhaFFPRO_Android no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Use Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Instale o APK gerado e conceda permissão de sobreposição quando solicitada.
