package com.massinhffpro;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    final String FF="com.dts.freefireth";
    LinearLayout base, games; TextView status;
    int bg=Color.rgb(6,11,19), panel=Color.rgb(14,26,40), cyan=Color.rgb(60,211,255), white=Color.rgb(238,248,255);
    public void onCreate(Bundle b){super.onCreate(b); build();}
    TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);return t;}
    GradientDrawable shape(int c,int stroke){GradientDrawable d=new GradientDrawable();d.setColor(c);d.setCornerRadius(28);if(stroke!=0)d.setStroke(2,stroke);return d;}
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(28,24,28,24);l.setBackground(shape(panel,Color.rgb(27,58,82)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.setMargins(0,10,0,10);base.addView(l,p);return l;}
    Button btn(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.rgb(0,18,28));b.setAllCaps(false);b.setTextSize(14);b.setBackground(shape(cyan,0));return b;}
    void build(){
        ScrollView sc=new ScrollView(this);base=new LinearLayout(this);base.setOrientation(1);base.setPadding(28,35,28,35);base.setBackgroundColor(bg);sc.addView(base);setContentView(sc);
        TextView title=text("⚡  MASSINHA FF PRO",22,white);title.setTypeface(null,Typeface.BOLD);base.addView(title);
        TextView sub=text("TOUCH OPTIMIZE  •  BETA 0.2",10,cyan);base.addView(sub);
        LinearLayout hero=card();hero.addView(text("SEU JOGO, SEU CONTROLE",11,cyan));TextView h=text("GAME SPACE",25,white);h.setTypeface(null,1);hero.addView(h);hero.addView(text("Painel de jogos e ajustes experimentais para Android.",13,Color.LTGRAY));
        LinearLayout perf=card();perf.addView(text("MONITORAMENTO",16,white));ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();am.getMemoryInfo(mi);long used=(mi.totalMem-mi.availMem)/1024/1024;perf.addView(text("RAM em uso: "+used+" MB  •  Bateria: "+battery()+"%",13,cyan));
        LinearLayout library=card();TextView label=text("BIBLIOTECA DE JOGOS",16,white);library.addView(label);status=text("Free Fire ainda não adicionado",12,Color.LTGRAY);library.addView(status);
        Button add=btn("＋  Adicionar jogo");library.addView(add);add.setOnClickListener(v->showApps());
        Button play=btn("▶  JOGAR FREE FIRE");library.addView(play);play.setOnClickListener(v->launchGame());
        LinearLayout settings=card();settings.addView(text("AJUSTES MASSINHA",16,white));
        addSwitch(settings,"Preset visual massinha (experimental)",false);
        addSwitch(settings,"Cores mais vivas (preferência)",true);
        addSwitch(settings,"Perfil leve para celular fraco",true);
        settings.addView(text("Resolução / sombras / texturas internas do Free Fire não podem ser alteradas por este painel sem suporte oficial do jogo.",11,Color.rgb(220,190,130)));
        LinearLayout overlay=card();overlay.addView(text("ATALHO FLUTUANTE",16,white));Button ob=btn("Ativar bolinha sobre outros apps");overlay.addView(ob);ob.setOnClickListener(v->enableOverlay());
        base.addView(text("Galaxy A50 • Android 11  |  Configurações experimentais",10,Color.GRAY));
    }
    int battery(){Intent i=registerReceiver(null,new android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED));if(i==null)return -1;int l=i.getIntExtra("level",-1),s=i.getIntExtra("scale",-1);return s>0?l*100/s:-1;}
    void addSwitch(LinearLayout parent,String label,boolean checked){Switch s=new Switch(this);s.setText(label);s.setTextColor(white);s.setTextSize(13);s.setChecked(checked);parent.addView(s);}
    void showApps(){
        ArrayList<ResolveInfo> apps=new ArrayList<>(getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0));
        Collections.sort(apps,(a,b)->String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(getPackageManager()).toString(),b.loadLabel(getPackageManager()).toString()));
        LinearLayout list=new LinearLayout(this);list.setOrientation(1);ScrollView sv=new ScrollView(this);sv.addView(list);
        final AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Escolha um aplicativo").setView(sv).setNegativeButton("Fechar",null).create();
        for(ResolveInfo r:apps){String name=r.loadLabel(getPackageManager()).toString(),p=r.activityInfo.packageName;Button x=new Button(this);x.setText(name+"   + Adicionar");x.setAllCaps(false);list.addView(x);x.setOnClickListener(v->{status.setText(name+" • "+p);Toast.makeText(this,name+" adicionado à biblioteca",Toast.LENGTH_SHORT).show();dlg.dismiss();});}
        dlg.show();
    }
    void launchGame(){Intent i=getPackageManager().getLaunchIntentForPackage(FF);if(i==null){new AlertDialog.Builder(this).setMessage("Free Fire normal não foi encontrado. Instale o jogo oficial e tente novamente.").setPositiveButton("OK",null).show();return;}try{startActivity(i);}catch(Exception e){Toast.makeText(this,"Não foi possível abrir o Free Fire.",Toast.LENGTH_LONG).show();}}
    void enableOverlay(){if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()));startActivity(i);return;}startService(new Intent(this,OverlayService.class));Toast.makeText(this,"Bolinha ativada. Ela oferece atalho para abrir o Free Fire.",Toast.LENGTH_LONG).show();}
}
