package com.massinhffpro;
import android.app.*;import android.content.*;import android.graphics.*;import android.graphics.drawable.*;import android.net.Uri;import android.os.*;import android.provider.Settings;import android.view.*;import android.widget.*;
public class OverlayService extends Service {
 WindowManager wm; View bubble; WindowManager.LayoutParams lp;
 public IBinder onBind(Intent i){return null;}
 public int onStartCommand(Intent i,int f,int id){if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY;}show();return START_STICKY;}
 void show(){if(bubble!=null)return;wm=(WindowManager)getSystemService(WINDOW_SERVICE);TextView t=new TextView(this);t.setText("Z");t.setTextColor(Color.BLACK);t.setTextSize(22);t.setGravity(Gravity.CENTER);GradientDrawable d=new GradientDrawable();d.setShape(1);d.setColor(Color.rgb(50,210,255));d.setStroke(3,Color.WHITE);t.setBackground(d);bubble=t;
 lp=new WindowManager.LayoutParams(58,58,Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT);lp.gravity=Gravity.RIGHT|Gravity.CENTER_VERTICAL;lp.x=18;
 t.setOnClickListener(v->{Intent launch=getPackageManager().getLaunchIntentForPackage("com.dts.freefireth");if(launch!=null){launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(launch);}else Toast.makeText(this,"Free Fire não encontrado",Toast.LENGTH_SHORT).show();});
 t.setOnLongClickListener(v->{stopSelf();return true;});wm.addView(t,lp);}
 public void onDestroy(){if(wm!=null&&bubble!=null)try{wm.removeView(bubble);}catch(Exception ignored){}super.onDestroy();}
}
